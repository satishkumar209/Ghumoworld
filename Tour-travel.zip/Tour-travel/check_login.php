<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    // user not logged in → save hotel & redirect to login
    $_SESSION['redirect_after_login'] = $_GET['hotel'];
    header("Location: login.php");
    exit;
}

// user logged in → go to booking
$hotel = urlencode($_GET['hotel']);
header("Location: booking.php?hotel=$hotel");
exit;
