<?php
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

/* Get hotel ID */
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

/* If delete confirmed */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['id']);
    $conn->query("DELETE FROM hotels WHERE id = $id");
    header("Location: admin_hotels.php?deleted=1");
    exit;
}

/* Fetch hotel details for display */
$hotel = $conn->query("SELECT hotel_name FROM hotels WHERE id = $id")->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
<title>Delete Hotel</title>

<style>
*{
    font-family:'Segoe UI',sans-serif;
    box-sizing:border-box;
}

body{
    background:linear-gradient(120deg,#667eea,#764ba2);
    min-height:100vh;
    display:flex;
    align-items:center;
    justify-content:center;
}

.modal{
    background:#fff;
    width:380px;
    padding:30px;
    border-radius:16px;
    box-shadow:0 20px 45px rgba(0,0,0,.3);
    text-align:center;
    animation:pop .3s ease;
}

@keyframes pop{
    from{transform:scale(.9);opacity:0}
    to{transform:scale(1);opacity:1}
}

.modal h2{
    color:#dc3545;
    margin-bottom:10px;
}

.modal p{
    color:#555;
    margin-bottom:25px;
}

.actions{
    display:flex;
    justify-content:space-between;
    gap:15px;
}

.btn{
    flex:1;
    padding:12px;
    border:none;
    border-radius:8px;
    font-size:15px;
    cursor:pointer;
}

.cancel{
    background:#6c757d;
    color:#fff;
}

.delete{
    background:#dc3545;
    color:#fff;
}

.cancel:hover{background:#5a6268;}
.delete:hover{background:#c82333;}
</style>
</head>

<body>

<div class="modal">
    <h2>⚠ Delete Hotel</h2>
    <p>
        Are you sure you want to delete  
        <strong><?= htmlspecialchars($hotel['hotel_name'] ?? 'this hotel') ?></strong>?
        <br><br>
        This action <b>cannot be undone</b>.
    </p>

    <form method="post">
        <input type="hidden" name="id" value="<?= $id ?>">
        <div class="actions">
            <button type="button" class="btn cancel"
                onclick="window.location.href='admin_hotels.php'">
                Cancel
            </button>

            <button type="submit" class="btn delete">
                Delete
            </button>
        </div>
    </form>
</div>  

</body>
</html>
