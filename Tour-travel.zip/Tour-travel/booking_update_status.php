<?php
require_once 'admin_auth.php';
require_once '../db_connect.php';

$id = $_GET['id'];
$status = $_POST['status'];

$conn->query("UPDATE bookings SET status='$status' WHERE id=$id");
header("Location: admin_bookings.php");
?>