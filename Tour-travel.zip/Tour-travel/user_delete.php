<?php
require_once 'admin_auth.php';
require_once '../db_connect.php';

$id = $_GET['id'];
$conn->query("DELETE FROM users WHERE id=$id");

header("Location: admin_users.php");
?>