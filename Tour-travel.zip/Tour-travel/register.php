<?php
require_once 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Sanitize input
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $mobile = $conn->real_escape_string($_POST['mobile']);
    $location = $conn->real_escape_string($_POST['location']);
    $destination = $conn->real_escape_string($_POST['destination']);
    $password = $_POST['password'];

    // Hash password
    $password_hash = password_hash($password, PASSWORD_DEFAULT);

    // Check if email already exists
    $check_sql = "SELECT id FROM users WHERE email = '$email'";
    $result = $conn->query($check_sql);

    if ($result->num_rows > 0) {
        // Email already registered
        echo "<script>
                alert('Email already registered. Please login.');
                window.location.href = 'login.php';
              </script>";
        exit;
    }

    // Insert user
    $insert_sql = "INSERT INTO users 
                   (name, email, mobile, location, destination, password_hash)
                   VALUES 
                   ('$name', '$email', '$mobile', '$location', '$destination', '$password_hash')";

    if ($conn->query($insert_sql) === TRUE) {

        // ✅ Redirect to login page after success
        header("Location: login.php");
        exit;

    } else {
        echo "Error during registration: " . $conn->error;
    }

} else {
    echo "Invalid request method.";
}

$conn->close();
?>
