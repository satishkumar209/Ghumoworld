<?php
require_once 'admin_auth.php';
require_once '../db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name  = $_POST['name'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $sql = "INSERT INTO users (name,email,mobile,password_hash)
            VALUES ('$name','$email','$mobile','$password')";
    $conn->query($sql);

    header("Location: admin_users.php");
}
?>
<form method="post">
    <input name="name" placeholder="Name" required>
    <input name="email" placeholder="Email" required>
    <input name="mobile" placeholder="Mobile" required>
    <input name="password" type="password" placeholder="Password" required>
    <button>Add User</button>
</form>
