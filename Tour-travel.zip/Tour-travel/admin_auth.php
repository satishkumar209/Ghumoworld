<?php
session_start();
require_once 'db_connect.php'; 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Input ko trim karein taaki faltu space na rahein
    $email = trim($conn->real_escape_string($_POST['email']));
    $password = trim($_POST['password']);

    // Database se record nikalne ki query
    $sql = "SELECT id, password_hash, email FROM admins WHERE email = '$email'";
    $result = $conn->query($sql);

    if ($result && $result->num_rows == 1) {
        $user = $result->fetch_assoc();
        
        // NORMAL PASSWORD CHECK: Ab hum direct match kar rahe hain
        if ($password === $user['password_hash']) {
            // Success: Session variables set karein
            $_SESSION['admin_id'] = $user['id'];
            $_SESSION['admin_email'] = $user['email'];

            header("Location: admin_dashboard.php");
            exit(); 
        }
    }

    // Agar password match nahi hua toh ye alert aayega
    echo "<script>
            alert('Invalid Admin Credentials');
            window.location.href = 'admin_login.php';
          </script>";
    exit();
}
$conn->close();
?>