<?php
session_start();
require_once 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name  = $_POST['hotel_name'];
    $city  = $_POST['city'];
    $price = $_POST['price'];

    $conn->query("INSERT INTO hotels (hotel_name, city, price)
                  VALUES ('$name','$city','$price')");
    header("Location: admin_hotels.php");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Add Hotel</title>

<style>
*{
    box-sizing:border-box;
    font-family:'Segoe UI',sans-serif;
}

body{
    background:linear-gradient(120deg,#667eea,#764ba2);
    min-height:100vh;
    display:flex;
    align-items:center;
    justify-content:center;
}

.card{
    background:#fff;
    width:420px;
    padding:30px;
    border-radius:16px;
    box-shadow:0 15px 40px rgba(0,0,0,.25);
}

.card h2{
    text-align:center;
    margin-bottom:20px;
    color:#333;
}

.form-group{
    margin-bottom:15px;
}

label{
    font-weight:600;
    display:block;
    margin-bottom:5px;
}

input{
    width:100%;
    padding:12px;
    border-radius:8px;
    border:1px solid #ccc;
    font-size:14px;
}

input:focus{
    outline:none;
    border-color:#667eea;
}

.btn{
    width:100%;
    padding:12px;
    border:none;
    border-radius:8px;
    background:#667eea;
    color:#fff;
    font-size:16px;
    cursor:pointer;
    margin-top:10px;
}

.btn:hover{
    background:#5a6fdc;
}

.back{
    text-align:center;
    margin-top:15px;
}

.back a{
    text-decoration:none;
    color:#667eea;
    font-weight:bold;
}
</style>
</head>

<body>

<div class="card">
    <h2>➕ Add New Hotel</h2>

    <form method="post">
        <div class="form-group">
            <label>Hotel Name</label>
            <input type="text" name="hotel_name" required>
        </div>

        <div class="form-group">
            <label>City</label>
            <input type="text" name="city" required>
        </div>

        <div class="form-group">
            <label>Price per Night (₹)</label>
            <input type="number" name="price" required>
        </div>

        <button class="btn">Add Hotel</button>
    </form>
