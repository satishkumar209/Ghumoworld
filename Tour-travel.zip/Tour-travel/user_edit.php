<?php
require_once 'admin_auth.php';
require_once '../db_connect.php';

$id = $_GET['id'];
$user = $conn->query("SELECT * FROM users WHERE id=$id")->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name  = $_POST['name'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];

    $conn->query("UPDATE users SET name='$name', email='$email', mobile='$mobile' WHERE id=$id");
    header("Location: admin_users.php");
}
?>
<form method="post">
    <input name="name" value="<?= $user['name'] ?>">
    <input name="email" value="<?= $user['email'] ?>">
    <input name="mobile" value="<?= $user['mobile'] ?>">
    <button>Update</button>
</form>
