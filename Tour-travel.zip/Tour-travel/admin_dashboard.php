
<?php
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

$users = $conn->query("SELECT COUNT(*) AS total FROM users")->fetch_assoc()['total'];
$hotels = $conn->query("SELECT COUNT(*) AS total FROM hotels")->fetch_assoc()['total'];
$bookings = $conn->query("SELECT COUNT(*) AS total FROM hotel_bookings")->fetch_assoc()['total'];
?>
<!DOCTYPE html>
<html>
<head>
<title>Admin Dashboard</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
<style>
.sidebar {
    width: 240px;
    background: #212529;
    min-height: 100vh;
    position: fixed;
}
.sidebar a {
    color: #fff;
    padding: 14px;
    display: block;
    text-decoration: none;
}
.sidebar a:hover { background: #0d6efd; }
.content { margin-left: 240px; padding: 30px; }
.card { border-radius: 15px; }
</style>
</head>

<body>

<div class="sidebar">
    <h4 class="text-center text-white py-3">GhumoWorld Admin</h4>
    <a href="admin_dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
    <a href="admin_users.php"><i class="bi bi-people"></i> Users</a>
    <a href="admin_hotels.php"><i class="bi bi-building"></i> Hotels</a>
    <a href="admin_bookings.php"><i class="bi bi-journal"></i> Bookings</a>
    <a href="admin_logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a>
</div>

<div class="content">
    <h3>Admin Dashboard</h3>

    <div class="row mt-4">
        <div class="col-md-4">
            <div class="card text-white bg-primary p-3">
                <h5>Total Users</h5>
                <h2><?= $users ?></h2>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-white bg-success p-3">
                <h5>Total Hotels</h5>
                <h2><?= $hotels ?></h2>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-white bg-warning p-3">
                <h5>Total Bookings</h5>
                <h2><?= $bookings ?></h2>
            </div>
        </div>
    </div>
</div>

</body>
</html>
