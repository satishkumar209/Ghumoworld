<?php
session_start();

/* Remove ONLY admin session */
unset($_SESSION['admin_id']);
unset($_SESSION['admin_email']); // if used

header("Location: admin_login.php");
exit;
