<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$hotel = $_GET['hotel'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Book Hotel</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap + Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body {
            background: linear-gradient(to right, #1f4037, #99f2c8);
            min-height: 100vh;
        }
        .booking-card {
            background: #fff;
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0px 15px 40px rgba(0,0,0,0.25);
            margin-top: 80px;
        }
        .hotel-title {
            font-weight: 700;
            color: #2c3e50;
        }
        .btn-book {
            border-radius: 30px;
            padding: 12px;
            font-size: 18px;
            font-weight: 600;
        }
        .form-control {
            border-radius: 12px;
        }
        .icon-box {
            font-size: 40px;
            color: #28a745;
        }
    </style>
</head>

<body>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">

            <div class="booking-card">

                <div class="text-center mb-4">
                    <div class="icon-box">
                        <i class="bi bi-building-check"></i>
                    </div>
                    <h3 class="hotel-title mt-2">
                        <?php echo htmlspecialchars($hotel); ?>
                    </h3>
                    <p class="text-muted">Confirm your stay details</p>
                </div>

                <form method="POST" action="booking_process.php">
                    <input type="hidden" name="hotel_name" value="<?php echo htmlspecialchars($hotel); ?>">

                    <div class="mb-3">
                        <label class="form-label">
                            <i class="bi bi-calendar-check"></i> Check-in Date
                        </label>
                        <input type="date" name="check_in" class="form-control" required>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">
                            <i class="bi bi-calendar-x"></i> Check-out Date
                        </label>
                        <input type="date" name="check_out" class="form-control" required>
                    </div>

                    <button type="submit" class="btn btn-success btn-book w-100">
                        <i class="bi bi-check-circle"></i> Confirm Booking
                    </button>
                </form>

                <div class="text-center mt-4">
                    <a href="dashboard.php" class="text-decoration-none">
                        <i class="bi bi-arrow-left"></i> Back to Dashboard
                    </a>
                </div>

            </div>

        </div>
    </div>
</div>

</body>
</html>
