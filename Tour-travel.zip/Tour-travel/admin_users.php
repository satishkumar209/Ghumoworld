<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}
require_once 'db_connect.php';

$sql = "SELECT id, name, email, mobile, created_at FROM users ORDER BY id DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin | Users</title>

<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Segoe UI', sans-serif;
}

body {
    background: linear-gradient(120deg, #667eea, #764ba2);
    min-height: 100vh;
    padding: 30px;
}

/* Container */
.container {
    background: #ffffff;
    border-radius: 15px;
    padding: 25px;
    box-shadow: 0 15px 40px rgba(0,0,0,0.2);
}

/* Header */
.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.header h2 {
    color: #333;
}

.logout a {
    background: #ff4b5c;
    color: #fff;
    padding: 8px 14px;
    border-radius: 8px;
    text-decoration: none;
    font-weight: bold;
}

.logout a:hover {
    background: #e63b4a;
}

/* Search */
.search-box {
    margin: 15px 0;
}

.search-box input {
    width: 300px;
    padding: 10px;
    border-radius: 8px;
    border: 1px solid #ccc;
    outline: none;
}

/* Table */
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 10px;
}

thead {
    background: linear-gradient(120deg, #667eea, #764ba2);
    color: #fff;
}

th, td {
    padding: 12px;
    text-align: center;
}

tbody tr {
    border-bottom: 1px solid #eee;
    transition: 0.3s;
}

tbody tr:hover {
    background: #f3f4ff;
    transform: scale(1.01);
}

.badge {
    padding: 5px 10px;
    border-radius: 6px;
    background: #28a745;
    color: #fff;
    font-size: 12px;
}

/* Responsive */
@media (max-width: 768px) {
    .search-box input {
        width: 100%;
    }
    table {
        font-size: 14px;
    }
}
</style>

<script>
function searchUsers() {
    let input = document.getElementById("searchInput").value.toLowerCase();
    let rows = document.querySelectorAll("tbody tr");

    rows.forEach(row => {
        let text = row.innerText.toLowerCase();
        row.style.display = text.includes(input) ? "" : "none";
    });
}
</script>

</head>
<body>

<div class="container">

    <div class="header">
        <h2>👥 Registered Users</h2>
        <div class="logout">
            <a href="admin_logout.php">Logout</a>
        </div>
    </div>

    <div class="search-box">
        <input type="text" id="searchInput" onkeyup="searchUsers()" placeholder="🔍 Search users...">
    </div>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Mobile</th>
                <th>Registered On</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['id']}</td>
                        <td>{$row['name']}</td>
                        <td>{$row['email']}</td>
                        <td>{$row['mobile']}</td>
                        <td>{$row['created_at']}</td>
                        <td><span class='badge'>Active</span></td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='6'>No users found</td></tr>";
        }
        ?>
        </tbody>
    </table>

</div>

</body>
</html>
