<?php
session_start();
require_once 'db_connect.php';

$id = $_GET['id'];
$hotel = $conn->query("SELECT * FROM hotels WHERE id=$id")->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $conn->query("UPDATE hotels SET
        hotel_name='{$_POST['hotel_name']}',
        city='{$_POST['city']}',
        price='{$_POST['price']}'
        WHERE id=$id");

    header("Location: admin_hotels.php");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Edit Hotel</title>

<style>
*{
    box-sizing:border-box;
    font-family:'Segoe UI',sans-serif;
}

body{
    background:linear-gradient(120deg,#667eea,#764ba2);
    min-height:100vh;
    display:flex;
    align-items:center;
    justify-content:center;
}

.card{
    background:#fff;
    width:420px;
    padding:30px;
    border-radius:16px;
    box-shadow:0 15px 40px rgba(0,0,0,.25);
}

.card h2{
    text-align:center;
    margin-bottom:20px;
    color:#333;
}

.form-group{
    margin-bottom:15px;
}

label{
    font-weight:600;
    display:block;
    margin-bottom:5px;
}

input{
    width:100%;
    padding:12px;
    border-radius:8px;
    border:1px solid #ccc;
    font-size:14px;
}

input:focus{
    outline:none;
    border-color:#667eea;
}

.btn{
    width:100%;
    padding:12px;
    border:none;
    border-radius:8px;
    background:#28a745;
    color:#fff;
    font-size:16px;
    cursor:pointer;
    margin-top:10px;
}

.btn:hover{
    background:#218838;
}

.back{
    text-align:center;
    margin-top:15px;
}

.back a{
    text-decoration:none;
    color:#667eea;
    font-weight:bold;
}
</style>
</head>

<body>

<div class="card">
    <h2>✏️ Edit Hotel</h2>

    <form method="post">
        <div class="form-group">
            <label>Hotel Name</label>
            <input type="text" name="hotel_name" value="<?= $hotel['hotel_name'] ?>" required>
        </div>

        <div class="form-group">
            <label>City</label>
            <input type="text" name="city" value="<?= $hotel['city'] ?>" required>
        </div>

        <div class="form-group">
            <label>Price per Night (₹)</label>
            <input type="number" name="price" value="<?= $hotel['price'] ?>" required>
        </div>

        <button class="btn">Update Hotel</button>
    </form>

    <div class="back">
        <a href="admin_hotels.php">← Back to Hotels</a>
    </div>
</div>

</body>
</html>
