<?php
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$result = $conn->query("SELECT * FROM hotel_bookings WHERE user_id=$user_id ORDER BY booking_date DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>My Bookings</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body {
            background: linear-gradient(to right, #141e30, #243b55);
            min-height: 100vh;
        }
        .booking-card {
            background: #fff;
            border-radius: 18px;
            padding: 25px;
            box-shadow: 0px 15px 35px rgba(0,0,0,0.25);
        }
        .badge-confirmed {
            background: linear-gradient(135deg, #28a745, #6ddf95);
        }
        .table thead {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: #fff;
        }
        .back-btn {
            border-radius: 30px;
        }
    </style>
</head>

<body>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-lg-10">

            <div class="booking-card">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h3><i class="bi bi-journal-bookmark-fill"></i> My Bookings</h3>
                    <a href="profile.php" class="btn btn-outline-secondary back-btn">
                        <i class="bi bi-arrow-left"></i> Profile
                    </a>
                </div>

                <?php if ($result->num_rows > 0) { ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead>
                                <tr>
                                    <th>Hotel</th>
                                    <th>Check-in</th>
                                    <th>Check-out</th>
                                    <th>Status</th>
                                    <th>Booked On</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php while($row = $result->fetch_assoc()) { ?>
                                <tr>
                                    <td>
                                        <i class="bi bi-building"></i>
                                        <?php echo htmlspecialchars($row['hotel_name']); ?>
                                    </td>
                                    <td><?php echo $row['check_in']; ?></td>
                                    <td><?php echo $row['check_out']; ?></td>
                                    <td>
                                        <span class="badge badge-confirmed">
                                            <?php echo $row['status']; ?>
                                        </span>
                                    </td>
                                    <td><?php echo $row['booking_date']; ?></td>
                                </tr>
                            <?php } ?>
                            </tbody>
                        </table>
                    </div>
                <?php } else { ?>
                    <div class="alert alert-info text-center">
                        <i class="bi bi-info-circle"></i> No bookings found yet.
                    </div>
                <?php } ?>
            </div>

        </div>
    </div>
</div>

</body>
</html>
