<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Login | GhumoWorld</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap + Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body {
            background: linear-gradient(to right, #141e30, #243b55);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-card {
            border-radius: 20px;
            box-shadow: 0px 20px 50px rgba(0,0,0,0.3);
            overflow: hidden;
        }
        .login-header {
            background: #0d6efd;
            color: #fff;
            padding: 25px;
            text-align: center;
        }
        .login-body {
            padding: 30px;
        }
        .form-control {
            border-radius: 12px;
            padding: 12px;
        }
        .btn-login {
            border-radius: 30px;
            padding: 12px;
            font-weight: bold;
        }
    </style>
</head>

<body>

<div class="col-md-5 col-lg-4">
    <div class="card login-card">
        <div class="login-header">
            <i class="bi bi-shield-lock-fill fs-1"></i>
            <h3 class="mt-2">Admin Login</h3>
            <p class="mb-0">GhumoWorld Admin Panel</p>
        </div>

        <div class="login-body">
            <form action="admin_auth.php" method="POST">
                <div class="mb-3">
                    <label class="form-label">
                        <i class="bi bi-envelope"></i> Email
                    </label>
                    <input type="email" name="email" class="form-control" required>
                </div>

                <div class="mb-4">
                    <label class="form-label">
                        <i class="bi bi-lock"></i> Password
                    </label>
                    <input type="password" name="password" class="form-control" required>
                </div>

                <button type="submit" class="btn btn-primary btn-login w-100">
                    <i class="bi bi-box-arrow-in-right"></i> Login
                </button>
            </form>
        </div>
    </div>
</div>

</body>
</html>
