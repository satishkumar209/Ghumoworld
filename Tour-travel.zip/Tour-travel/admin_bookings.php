<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

require_once 'db_connect.php';

/* ===============================
   UPDATE BOOKING STATUS (FIXED)
================================*/
if (isset($_POST['update_status'])) {

    $booking_id = intval($_POST['booking_id']);
    $status = $_POST['status'];   // must match ENUM values exactly

    $stmt = $conn->prepare(
        "UPDATE hotel_bookings SET `status` = ? WHERE id = ?"
    );
    $stmt->bind_param("si", $status, $booking_id);

    if (!$stmt->execute()) {
        die("Status Update Failed: " . $stmt->error);
    }

    $stmt->close();
    header("Location: admin_bookings.php?updated=1");
    exit;
}

/* ===============================
   DELETE BOOKING
================================*/
if (isset($_POST['confirm_delete'])) {

    $booking_id = intval($_POST['booking_id']);

    $stmt = $conn->prepare(
        "DELETE FROM hotel_bookings WHERE id = ?"
    );
    $stmt->bind_param("i", $booking_id);
    $stmt->execute();
    $stmt->close();

    header("Location: admin_bookings.php?deleted=1");
    exit;
}

/* ===============================
   FETCH BOOKINGS
================================*/
$sql = "
SELECT 
    hb.id,
    hb.hotel_name,
    hb.check_in,
    hb.check_out,
    hb.booking_date,
    hb.total_price,
    hb.status,
    u.name
FROM hotel_bookings hb
INNER JOIN users u ON hb.user_id = u.id
ORDER BY hb.id DESC
";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin | Bookings</title>

<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:'Segoe UI',sans-serif;}

body{
    background:linear-gradient(120deg,#667eea,#764ba2);
    min-height:100vh;
    padding:30px;
}

.container{
    background:#fff;
    border-radius:15px;
    padding:25px;
    box-shadow:0 15px 40px rgba(0,0,0,.25);
}

.header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:20px;
}

.logout a{
    background:#ff4b5c;
    color:#fff;
    padding:8px 14px;
    border-radius:8px;
    text-decoration:none;
    font-weight:bold;
}

.search-box{margin:15px 0;}
.search-box input{
    width:320px;
    padding:10px;
    border-radius:8px;
    border:1px solid #ccc;
}

table{width:100%;border-collapse:collapse;}
thead{
    background:linear-gradient(120deg,#667eea,#764ba2);
    color:#fff;
}
th,td{padding:12px;text-align:center;}

tbody tr{border-bottom:1px solid #eee;}
tbody tr:hover{background:#f3f4ff;}

select{padding:6px;border-radius:6px;}

.btn{
    padding:6px 12px;
    border:none;
    border-radius:6px;
    cursor:pointer;
}

.update{background:#28a745;color:#fff;}
.delete{background:#dc3545;color:#fff;}

.modal-bg{
    position:fixed;
    inset:0;
    background:rgba(0,0,0,.6);
    display:none;
    align-items:center;
    justify-content:center;
}

.modal{
    background:#fff;
    padding:25px;
    border-radius:16px;
    width:380px;
    text-align:center;
}
</style>

<script>
function searchBookings(){
    let input=document.getElementById("searchInput").value.toLowerCase();
    document.querySelectorAll("tbody tr").forEach(row=>{
        row.style.display=row.innerText.toLowerCase().includes(input)?"":"none";
    });
}

function openDelete(id){
    document.getElementById('delete_id').value=id;
    document.getElementById('deleteModal').style.display='flex';
}

function closeDelete(){
    document.getElementById('deleteModal').style.display='none';
}
</script>

</head>
<body>

<?php if (isset($_GET['updated'])) { ?>
<script>alert("✅ Booking status updated successfully");</script>
<?php } ?>

<?php if (isset($_GET['deleted'])) { ?>
<script>alert("🗑 Booking deleted successfully");</script>
<?php } ?>

<div class="container">

<div class="header">
    <h2>📑 Bookings Management</h2>
    <div class="logout"><a href="admin_logout.php">Logout</a></div>
</div>

<div class="search-box">
    <input type="text" id="searchInput" onkeyup="searchBookings()" placeholder="🔍 Search bookings...">
</div>

<table>
<thead>
<tr>
    <th>ID</th>
    <th>User</th>
    <th>Hotel</th>
    <th>Check In</th>
    <th>Check Out</th>
    <th>Booking Date</th>
    <th>Amount (₹)</th>
    <th>Status</th>
    <th>Actions</th>
</tr>
</thead>

<tbody>
<?php
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
?>
<tr>
    <td><?= $row['id'] ?></td>
    <td><?= htmlspecialchars($row['name']) ?></td>
    <td><?= htmlspecialchars($row['hotel_name']) ?></td>
    <td><?= $row['check_in'] ?></td>
    <td><?= $row['check_out'] ?></td>
    <td><?= $row['booking_date'] ?></td>
    <td><?= $row['total_price'] ?></td>

    <td>
        <form method="post" style="display:flex;gap:6px;justify-content:center;">
            <input type="hidden" name="booking_id" value="<?= $row['id'] ?>">
            <select name="status">
                <option value="Pending"   <?= $row['status']=='Pending'?'selected':'' ?>>Pending</option>
                <option value="Confirmed" <?= $row['status']=='Confirmed'?'selected':'' ?>>Confirmed</option>
                <option value="Cancelled" <?= $row['status']=='Cancelled'?'selected':'' ?>>Cancelled</option>
            </select>
            <button class="btn update" name="update_status">✔</button>
        </form>
    </td>

    <td>
        <button class="btn delete" onclick="openDelete(<?= $row['id'] ?>)">Delete</button>
    </td>
</tr>
<?php
    }
} else {
    echo "<tr><td colspan='9'>No bookings found</td></tr>";
}
?>
</tbody>
</table>

</div>

<!-- DELETE MODAL -->
<div class="modal-bg" id="deleteModal">
<div class="modal">
    <h3 style="color:#dc3545">⚠ Delete Booking</h3>
    <p>This action cannot be undone.</p>
    <form method="post">
        <input type="hidden" name="booking_id" id="delete_id">
        <button type="button" class="btn" onclick="closeDelete()">Cancel</button>
        <button class="btn delete" name="confirm_delete">Delete</button>
    </form>
</div>
</div>

</body>
</html>
