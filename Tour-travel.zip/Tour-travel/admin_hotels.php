<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

require_once 'db_connect.php';

$sql = "SELECT * FROM hotels ORDER BY id DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin | Hotels</title>

<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Segoe UI', sans-serif;
}

body {
    background: linear-gradient(120deg, #667eea, #764ba2);
    min-height: 100vh;
    padding: 30px;
}

.container {
    background: #ffffff;
    border-radius: 15px;
    padding: 25px;
    box-shadow: 0 15px 40px rgba(0,0,0,0.25);
}

.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.header h2 {
    color: #333;
}

.actions-top a {
    background: #28a745;
    color: #fff;
    padding: 8px 14px;
    border-radius: 8px;
    text-decoration: none;
    font-weight: bold;
    margin-right: 10px;
}

.logout a {
    background: #ff4b5c;
    color: #fff;
    padding: 8px 14px;
    border-radius: 8px;
    text-decoration: none;
    font-weight: bold;
}

.search-box {
    margin: 15px 0;
}

.search-box input {
    width: 320px;
    padding: 10px;
    border-radius: 8px;
    border: 1px solid #ccc;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 10px;
}

thead {
    background: linear-gradient(120deg, #667eea, #764ba2);
    color: #fff;
}

th, td {
    padding: 12px;
    text-align: center;
}

tbody tr {
    border-bottom: 1px solid #eee;
}

.action-btn {
    padding: 5px 10px;
    border-radius: 6px;
    text-decoration: none;
    color: #fff;
    font-size: 13px;
}

.edit {
    background: #007bff;
}

.delete {
    background: #dc3545;
}

@media (max-width: 768px) {
    table {
        font-size: 14px;
    }
}
</style>

<script>
function searchHotels() {
    let input = document.getElementById("searchInput").value.toLowerCase();
    let rows = document.querySelectorAll("tbody tr");

    rows.forEach(row => {
        row.style.display = row.innerText.toLowerCase().includes(input) ? "" : "none";
    });
}

function confirmDelete() {
    return confirm("Are you sure you want to delete this hotel?");
}
</script>

</head>
<body>

<div class="container">

    <div class="header">
        <h2>🏨 Hotel Management</h2>
        <div class="actions-top">
            <a href="hotel_add.php">➕ Add Hotel</a>
            <span class="logout">
                <a href="admin_logout.php">Logout</a>
            </span>
        </div>
    </div>

    <div class="search-box">
        <input type="text" id="searchInput" onkeyup="searchHotels()" placeholder="🔍 Search hotels...">
    </div>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Hotel Name</th>
                <th>City</th>
                <th>Price / Night (₹)</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>

        <?php
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['id']}</td>
                        <td>{$row['hotel_name']}</td>
                        <td>{$row['city']}</td>
                        <td>{$row['price']}</td>
                        <td>
                            <a class='action-btn edit' href='hotel_edit.php?id={$row['id']}'>Edit</a>
                            <a class='action-btn delete' href='hotel_delete.php?id={$row['id']}' onclick='return confirmDelete()'>Delete</a>
                        </td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='5'>No hotels found</td></tr>";
        }
        ?>

        </tbody>
    </table>

</div>

</body>
</html>
