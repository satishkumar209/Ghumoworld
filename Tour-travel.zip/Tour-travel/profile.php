<?php
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

$user = $conn->query("SELECT name, email FROM users WHERE id=$user_id")->fetch_assoc();
$bookingCount = $conn->query("SELECT COUNT(*) AS total FROM hotel_bookings WHERE user_id=$user_id")->fetch_assoc()['total'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Profile</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body {
            background: linear-gradient(to right, #0f2027, #203a43, #2c5364);
            min-height: 100vh;
            color: #fff;
        }
        .profile-box {
            background: #fff;
            color: #000;
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0px 15px 40px rgba(0,0,0,0.3);
            margin-top: 80px;
        }
        .avatar {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            background: linear-gradient(135deg, #ff7e5f, #feb47b);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 50px;
            font-weight: bold;
            color: #fff;
            margin: auto;
            box-shadow: 0px 10px 25px rgba(0,0,0,0.3);
        }
        .stat-card {
            border-radius: 15px;
            padding: 20px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: #fff;
            box-shadow: 0px 8px 25px rgba(0,0,0,0.25);
        }
        .btn-custom {
            border-radius: 30px;
            padding: 12px;
            font-weight: bold;
        }
    </style>
</head>

<body>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-7 col-lg-5">
            <div class="profile-box text-center">

                <div class="avatar">
                    <?php echo strtoupper($user['name'][0]); ?>
                </div>

                <h3 class="mt-3"><?php echo htmlspecialchars($user['name']); ?></h3>
                <p class="text-muted"><?php echo htmlspecialchars($user['email']); ?></p>

                <div class="row mt-4">
                    <div class="col-12">
                        <div class="stat-card">
                            <h5>Total Bookings</h5>
                            <h2><?php echo $bookingCount; ?></h2>
                        </div>
                    </div>
                </div>

                <div class="mt-4">
                    <a href="my_bookings.php" class="btn btn-primary btn-custom w-100 mb-3">
                        <i class="bi bi-journal-check"></i> My Booking History
                    </a>

                    <a href="dashboard.php" class="btn btn-outline-secondary btn-custom w-100 mb-3">
                        <i class="bi bi-house-door"></i> Dashboard
                    </a>

                    <a href="logout.php" class="btn btn-danger btn-custom w-100">
                        <i class="bi bi-box-arrow-right"></i> Logout
                    </a>
                </div>

            </div>
        </div>
    </div>
</div>

</body>
</html>
