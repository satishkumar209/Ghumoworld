<?php
require_once 'admin_auth.php';
require_once '../db_connect.php';

$id = $_GET['id'];
$conn->query("DELETE FROM bookings WHERE id=$id");

header("Location: admin_bookings.php");
?>