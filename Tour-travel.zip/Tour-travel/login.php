<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | GhumoWorld</title>

    <!-- Bootstrap + Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body {
            background: linear-gradient(to right, #1d2671, #c33764);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-card {
            border-radius: 20px;
            box-shadow: 0px 20px 50px rgba(0,0,0,0.3);
            overflow: hidden;
        }
        .login-header {
            background: linear-gradient(135deg, #0d6efd, #6610f2);
            color: #fff;
            padding: 25px;
            text-align: center;
        }
        .login-body {
            padding: 30px;
        }
        .form-control {
            border-radius: 12px;
            padding: 12px;
        }
        .btn-login {
            border-radius: 30px;
            padding: 12px;
            font-size: 18px;
            font-weight: 600;
        }
        .login-icon {
            font-size: 45px;
            margin-bottom: 10px;
        }
    </style>
</head>

<body>

<div class="col-md-5 col-lg-4">
    <div class="card login-card">

        <div class="login-header">
            <div class="login-icon">
                <i class="bi bi-person-circle"></i>
            </div>
            <h3>Welcome Back</h3>
            <p class="mb-0">Login to continue your journey</p>
        </div>

        <div class="login-body">
            <form action="auth.php" method="POST">

                <div class="mb-3">
                    <label class="form-label">
                        <i class="bi bi-envelope"></i> Email Address
                    </label>
                    <input type="email" class="form-control" name="email" placeholder="Enter your email" required>
                </div>

                <div class="mb-4">
                    <label class="form-label">
                        <i class="bi bi-lock"></i> Password
                    </label>
                    <input type="password" class="form-control" name="password" placeholder="Enter your password" required>
                </div>

                <button type="submit" class="btn btn-success btn-login w-100">
                    <i class="bi bi-box-arrow-in-right"></i> Login
                </button>
            </form>

            <div class="text-center mt-4">
                <span>Don't have an account?</span>
                <a href="signup.html" class="fw-bold text-decoration-none">
                    Sign Up
                </a>
            </div>
        </div>

    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
