<?php
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

/* Fetch user details */
$user = $conn->query("SELECT name, email FROM users WHERE id=$user_id")->fetch_assoc();

/* Fetch total bookings */
$totalBookings = $conn->query(
    "SELECT COUNT(*) AS total FROM hotel_bookings WHERE user_id=$user_id"
)->fetch_assoc()['total'];

/* Fetch latest booking */
$latestBooking = $conn->query(
    "SELECT hotel_name, check_in, check_out 
     FROM hotel_bookings 
     WHERE user_id=$user_id 
     ORDER BY booking_date DESC LIMIT 1"
)->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>User Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap + Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body {
            background: #f4f6f9;
        }
        .sidebar {
            width: 230px;
            background: #0d6efd;
            min-height: 100vh;
            position: fixed;
            color: #fff;
        }
        .sidebar a {
            color: #fff;
            display: block;
            padding: 14px;
            text-decoration: none;
        }
        .sidebar a:hover {
            background: #084298;
        }
        .content {
            margin-left: 230px;
            padding: 30px;
        }
        .card {
            border-radius: 15px;
            box-shadow: 0px 10px 25px rgba(0,0,0,0.1);
        }
        .stat-card {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
        }
    </style>
</head>

<body>

<!-- Sidebar -->
<div class="sidebar">
    <h4 class="text-center py-3">GhumoWorld</h4>
    <a href="user.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
    <a href="profile.php"><i class="bi bi-person"></i> My Profile</a>
    <a href="my_bookings.php"><i class="bi bi-journal-check"></i> My Bookings</a>
    <a href="logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a>
</div>

<!-- Main Content -->
<div class="content">

    <!-- Welcome -->
    <div class="mb-4">
        <h3>Welcome back, <?php echo htmlspecialchars($user['name']); ?> 👋</h3>
        <p class="text-muted"><?php echo htmlspecialchars($user['email']); ?></p>
    </div>

    <!-- Stats -->
    <div class="row mb-4">
        <div class="col-md-4">
            <div class="card stat-card p-3">
                <h5>Total Bookings</h5>
                <h2><?php echo $totalBookings; ?></h2>
            </div>
        </div>
    </div>

    <!-- Latest Booking -->
    <div class="card p-4 mb-4">
        <h5><i class="bi bi-clock-history"></i> Latest Booking</h5>

        <?php if ($latestBooking) { ?>
            <p><b>Hotel:</b> <?php echo htmlspecialchars($latestBooking['hotel_name']); ?></p>
            <p><b>Check-in:</b> <?php echo $latestBooking['check_in']; ?></p>
            <p><b>Check-out:</b> <?php echo $latestBooking['check_out']; ?></p>
            <a href="my_bookings.php" class="btn btn-primary btn-sm">
                View All Bookings
            </a>
        <?php } else { ?>
            <p class="text-muted">You haven't made any bookings yet.</p>
        <?php } ?>
    </div>

    <!-- Quick Actions -->
    <div class="card p-4">
        <h5><i class="bi bi-lightning-charge"></i> Quick Actions</h5>
        <div class="d-flex gap-3 mt-3">
            <a href="my_bookings.php" class="btn btn-outline-primary">
                My Bookings
            </a>
            <a href="profile.php" class="btn btn-outline-secondary">
                Edit Profile
            </a>
        </div>
    </div>

</div>

</body>
</html>
