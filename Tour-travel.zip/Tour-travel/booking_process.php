<?php
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id   = $_SESSION['user_id'];
$hotel     = $_POST['hotel_name'];
$check_in  = $_POST['check_in'];
$check_out = $_POST['check_out'];
$status    = "Pending";

/* --------------------------
   FETCH USER DETAILS
---------------------------*/
$userQuery = $conn->prepare("SELECT name, email, mobile FROM users WHERE id = ?");
$userQuery->bind_param("i", $user_id);
$userQuery->execute();
$user = $userQuery->get_result()->fetch_assoc();

$user_name  = $user['name'];
$user_email = $user['email'];
$user_mobile = $user['mobile'];

/* --------------------------
   INSERT BOOKING
---------------------------*/
$stmt = $conn->prepare(
    "INSERT INTO hotel_bookings (user_id, hotel_name, check_in, check_out, status)
     VALUES (?, ?, ?, ?, ?)"
);
$stmt->bind_param("issss", $user_id, $hotel, $check_in, $check_out, $status);

if ($stmt->execute()) {

    /* ==========================
       EMAIL CONFIRMATION
    ==========================*/
    $subject = "Hotel Booking Confirmation";
    $message = "
    Hello $user_name,

    Your hotel booking has been CONFIRMED successfully.

    Hotel Name: $hotel
    Check-in Date: $check_in
    Check-out Date: $check_out

    Thank you for choosing our service.

    Regards,
    Hotel Booking Team
    ";

    $headers = "From: no-reply@yourdomain.com";

    mail($user_email, $subject, $message, $headers);

    /* ==========================
       SMS CONFIRMATION
    ==========================*/
    // Example: Fast2SMS API (India)
    $sms_message = urlencode(
        "Hi $user_name, your booking at $hotel from $check_in to $check_out is CONFIRMED. Thank you!"
    );

    $api_key = "YOUR_FAST2SMS_API_KEY";

    $sms_url = "https://www.fast2sms.com/dev/bulkV2?"
        . "authorization=$api_key"
        . "&sender_id=FSTSMS"
        . "&message=$sms_message"
        . "&route=q"
        . "&numbers=$user_mobile";

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $sms_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_exec($ch);
    curl_close($ch);

    /* --------------------------
       REDIRECT
    ---------------------------*/
    header("Location: my_bookings.php?success=1");
    exit;

} else {
    echo "Booking failed. Please try again.";
}
?>
